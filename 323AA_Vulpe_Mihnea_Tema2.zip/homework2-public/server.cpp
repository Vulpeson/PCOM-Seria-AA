#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <string>
#include <iomanip>
#include <sstream>
#include <math.h>

using namespace std;

#define BUFLEN 1552
#define MAX_CLIENTS 100
// struct that stores the ID of the client and the socket
struct TCPclient{
    char ID_CLIENT[11];
    int socket;
};

// struct that stores the message
struct message {
    // store the port and IP of the sender
    char IP_CLIENT_UDP[16];
    int port;
    char topic[50];
    uint8_t data_type;
    union {
        struct{
            uint8_t sign;
            uint32_t uint32_value; // INT
        } int_value;
        
        
        uint16_t uint16_value; // SHORT_REAL
        
        struct {
            uint8_t sign;
            uint32_t modulus;
            uint8_t power;
        } number_value; // FLOAT
        // store the string value
        
        char string_value[1502]; // STRING


    } value;
    
    

};
// struct that stores the subscriber
struct subscriber {
    char ID_CLIENT[11];
    char topic[51];
    int SF;
    bool connected;
    vector<string> messages;
};

// vector that stores the clients connected
vector<TCPclient> clientsConnected;
// vector that stores the subscribtions
vector<subscriber> listOfSubscribersSF;

// function similar to lab 07 that receives all the bites
// not used because i did not know how to handle the segmentation of the messages
/* int recv_all(int sockfd, void* buffer, size_t len){
    size_t bytes_received = 0;
    size_t bytes_left = len;
    char* buff = (char*)buffer;
    while(bytes_received < len){
        int received = recv(sockfd, buff + bytes_received, bytes_left, 0);
        if(received < 0){
            return -1;
        }
        bytes_received += received;
        bytes_left -= received;
    }
    return bytes_received;
}
 */

int main(int argc, char *argv[])
{   
    // we check the arguments
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port_number>", argv[0]);
        exit(0);
    }
    // disable stdout buffering
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    
    // we get the port number
    int port = atoi(argv[1]);
    if(port == 0) {
        printf("Invalid port\n");
        return 1;
    }
    // we create the fd_set
    fd_set read_fds;
    fd_set tmp_fds;
    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);
    FD_SET(STDIN_FILENO, &read_fds);

    

    // we create the address
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t socket_len = sizeof(struct sockaddr_in);
    memset((char *)&serv_addr, 0, socket_len);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons((uint16_t)port);

    // we open a TCP socket
    int socketTCP = socket(AF_INET, SOCK_STREAM, 0);
    
    if(socketTCP< 0){
        printf("[SERV] Error while creating TCP socket\n");
        return -1;
    }
            
   
    
    
    // we bind the socket to the address and port
    int bindTCP = bind(socketTCP, (struct sockaddr *) &serv_addr, socket_len);
    if(bindTCP < 0){
        printf("[SERV] Error while binding TCP socket\n");
        return -1;
    }

    // we listen for connections
    int listenTCP = listen(socketTCP, MAX_CLIENTS);
    if(listenTCP < 0){
        printf("[SERV] Error while listening TCP socket\n");
        return -1;
    }
    // we disable neagle algorithm
    int neagle = 1;
    int res = setsockopt(socketTCP, IPPROTO_TCP, TCP_NODELAY, &neagle, sizeof(neagle));
    if(res < 0){
        printf("[SERV] Error while disabling neagle algorithm\n");
        return -1;
    }
    
    FD_SET(socketTCP, &read_fds);

    // we open a UDP socket
    int socketUDP = socket(AF_INET, SOCK_DGRAM, 0);
    if(socketUDP < 0){
        printf("[SERV] Error while creating UDP socket\n");
        return -1;
    }

    // we bind the socket to the address and port
    int bindUDP = bind(socketUDP, (struct sockaddr *) &serv_addr, socket_len);
    if(bindUDP < 0){
        printf("[SERV] Error while binding UDP socket\n");
        return -1;
    }

    // we add the sockets to the fd_set
    
    
    FD_SET(socketUDP, &read_fds);

    int fdmax = max(socketTCP, socketUDP);
    // fdax is the maximum value of the file descriptors
    // the main loop
    while(1){
        
        tmp_fds = read_fds;
        int selectRes = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
        if(selectRes < 0){
            printf("[SERV] Error while selecting\n");
            return -1;
        }

        // we check if we should exit

        if(FD_ISSET(STDIN_FILENO, &tmp_fds)){
            // we read from stdin
            char buffer[BUFLEN];
            memset(buffer, 0, BUFLEN);
            fgets(buffer, BUFLEN - 1, stdin);
            if(strncmp(buffer, "exit",4) == 0){
                // we disconnect all the clients
                for(int i = 0; i < (int)clientsConnected.size(); i++){
                    
                    char exit_message[BUFLEN];
                    memset(exit_message, 0, BUFLEN);
                    strcpy(exit_message, "exit");
                    int disconnect = send(clientsConnected[i].socket, exit_message, BUFLEN, 0);
                    if(disconnect < 0){
                        printf("[SERV] Error while disconnecting client\n");
                        return -1;
                    }
                    close(clientsConnected[i].socket);
                }
                break;
            }
            // i offer the debug option as i have experienced some problems even though the server works properly
            /* if(strncmp(buffer, "debug",5) == 0){
                // we disconnect all the clients
                // print the list of clients
                printf("List of clients:\n");
                for(int i = 0; i < (int)clientsConnected.size(); i++){
                    printf("%s\n", clientsConnected[i].ID_CLIENT);
                }
                printf("List of subscriptions - length %d\n", (int)listOfSubscribersSF.size());
                for(auto it = listOfSubscribersSF.begin(); it != listOfSubscribersSF.end(); it++){
                    printf("%s %s %d state: %d\n", it->ID_CLIENT, it->topic, it->SF, it->connected);
                    // if sf == 1 print the messages
                    
                    if(it->SF == 1){
                        printf("Messages:\n");
                        for(int i = 0; i < (int)it->messages.size(); i++){
                            printf("%s\n", it->messages[i].c_str());
                        }
                    }
                }
            } */
        }

        
        for (int sock = 1; sock <= fdmax; sock++){
            
            if(FD_ISSET(sock, &tmp_fds)){
                if(sock == socketUDP){
                    // we receive a message from a UDP client
                    
                    char buffer[BUFLEN];
                    memset(buffer, 0, BUFLEN);
                    int receive = recvfrom(socketUDP, buffer, BUFLEN, 0, (struct sockaddr *) &cli_addr, &socket_len);
                    if(receive < 0){
                        printf("[SERV] Error while receiving message\n");
                        return -1;
                    }
                    
                    buffer[receive] = '\0';
                    // a string that will store the human readable message 
                    string computed_message;
                    
                    
                    // we create a new message
                    message newMessage;

                    
                    memset(newMessage.IP_CLIENT_UDP, 0, 16);
                    strcpy(newMessage.IP_CLIENT_UDP, inet_ntoa(cli_addr.sin_addr));
                    newMessage.port = ntohs(cli_addr.sin_port);

                    // we add the IP and port of the sender
                    // we concatenate the IP to the computed message
                    computed_message += newMessage.IP_CLIENT_UDP;
                    computed_message += ":";
                    
                    // we convert the port to a string
                    computed_message += to_string(newMessage.port);
                    
                    computed_message += " - ";

                    memset(newMessage.topic, 0, 50);
                    memcpy(newMessage.topic, buffer, 50);
                    // we add the topic to the computed message
                    computed_message += newMessage.topic;
                    computed_message += " - ";

                    memcpy(&newMessage.data_type, buffer + 50, 1);

                    if(newMessage.data_type == 0){
                        // INT
                        memcpy(&newMessage.value.int_value.sign, buffer + 51, 1);
                        memcpy(&newMessage.value.int_value.uint32_value, buffer + 52, 4);
                        // we convert the number to the correct format
                        if(newMessage.value.int_value.sign == 1){
                            newMessage.value.int_value.uint32_value = ntohl(newMessage.value.int_value.uint32_value);
                            newMessage.value.int_value.uint32_value = -newMessage.value.int_value.uint32_value;
                        }
                        else{
                            newMessage.value.int_value.uint32_value = ntohl(newMessage.value.int_value.uint32_value);
                        }
                        
                        computed_message += "INT - ";
                        // we add the value to the computed message
                        if(newMessage.value.int_value.sign == 1){
                            computed_message += "-";
                            newMessage.value.int_value.uint32_value = -newMessage.value.int_value.uint32_value;
                        }
                        
                        computed_message += to_string(newMessage.value.int_value.uint32_value);

                    }
                    else{
                        if(newMessage.data_type == 1){
                            // SHORT_REAL
                            memcpy(&newMessage.value.uint16_value, buffer + 51, 2);
                            // we convert the number to the correct format
                            newMessage.value.uint16_value = ntohs(newMessage.value.uint16_value);
                            
                            computed_message += "SHORT_REAL - ";
                            // we add the value to the computed message
                            float value = (float)newMessage.value.uint16_value / 100;
                            stringstream stream;
                            stream << fixed << setprecision(2) << value;
                            string s = stream.str();
                            computed_message += s;
                        
                        }
                        else{
                            if(newMessage.data_type == 2){
                                // FLOAT
                                memcpy(&newMessage.value.number_value.sign, buffer + 51, 1);
                                memcpy(&newMessage.value.number_value.modulus, buffer + 52, 4);
                                memcpy(&newMessage.value.number_value.power, buffer + 56, 1);
                                // we convert the number to the correct format
                                newMessage.value.number_value.modulus = ntohl(newMessage.value.number_value.modulus);
                               
                                computed_message += "FLOAT - ";
                                // we add the value to the computed message
                                if(newMessage.value.number_value.sign == 1){
                                    computed_message += "-";
                                }
                                float value = (float)newMessage.value.number_value.modulus * pow(10, newMessage.value.number_value.power * (-1));
                                stringstream stream;
                                stream << fixed << setprecision(newMessage.value.number_value.power) << value;
                                string s = stream.str();
                                computed_message += s;
                            }
                            else{
                                if(newMessage.data_type == 3){
                                    // STRING
                                    int len = min(int(strlen(buffer + 51)), 1500);
                                    memcpy(newMessage.value.string_value, buffer + 51, len + 1);
                                    if (len > 1500)
                                    {
                                        newMessage.value.string_value[1500] = '\0';
                                    } 

                                    
                                    computed_message += "STRING - ";
                                    // we add the value to the computed message
                                    computed_message += newMessage.value.string_value;

                                }
                                else{
                                    printf("[SERV] invalid message\n");
                                    return -1;
                                }

                            }
                        }
                    }
                    
                    
                

                    
                    // we send the message to all the clients that are subscribed to the topic
                    for(auto it = listOfSubscribersSF.begin(); it != listOfSubscribersSF.end(); it++){
                            if(strcmp(it->topic, newMessage.topic) == 0){
                                // we have a match
                                
                                if(it->connected == true){
                                    
                                    // we search for the socket in the vector of clients
                                    for(int i = 0; i < (int)clientsConnected.size(); i++){
                                        if(strcmp(clientsConnected[i].ID_CLIENT, it->ID_CLIENT) == 0 ){
                                                // we found the client
                                            // we send the message to the client
                                            int socket = clientsConnected[i].socket;
                                            int s = send(socket, computed_message.c_str(), computed_message.size(), 0);
                                            if(s < 0){
                                                printf("[SERV] Error while sending message to client\n");
                                                return -1;
                                            }
                                        }
                                    }
                                }
                                else if(it->SF == 1){
                                    // we have to store the message for the client
                                    it->messages.push_back(computed_message);
                                }
                            }
                        }
                    
                      



                    ////////////////////////////////////////
                } else
                if(sock == socketTCP){
                        // we receive a message from a new TCP client
                        
                        int newSocket = accept(socketTCP, (struct sockaddr *) &cli_addr, &socket_len);
                        if(newSocket < 0){
                            printf("[SERV] Error while accepting new connection\n");
                            return -1;
                        }


                        // we receive the ID of the client
                        char ID_CLIENT[11];
                        memset(ID_CLIENT, 0, 11);
                        int receiveID = recv(newSocket, ID_CLIENT, 10, 0);
                        
                        if(receiveID < 0){
                            printf("[SERV] Error while receiving ID\n");
                            return -1;
                        }
                        
                        // we check if the ID is already in use
                        bool IDinUse = false;
                        for(int i = 0; i < (int)clientsConnected.size(); i++){
                            if(strcmp(clientsConnected[i].ID_CLIENT, ID_CLIENT) == 0){
                                IDinUse = true;
                                break;
                            }
                        }

                        // if the ID is not in use, we add the client to the list

                        if(IDinUse == false){
                            // we create a new client
                            TCPclient newClient;
                            memset(newClient.ID_CLIENT, 0, 11);
                            strcpy(newClient.ID_CLIENT, ID_CLIENT);
                            newClient.socket = newSocket;
                            // we add the new socket to the fd_set
                            FD_SET(newSocket, &read_fds);
                            if(newSocket > fdmax){
                                fdmax = newSocket;
                            }
                            
                            clientsConnected.push_back(newClient);

                            // we print that new client <ID> connected from <IP>:<PORT>
                            char message[BUFLEN];
                            memset(message, 0, BUFLEN);
                            strcpy(message, "New client ");
                            strcat(message, ID_CLIENT);
                            strcat(message, " connected from ");
                            strcat(message, inet_ntoa(cli_addr.sin_addr));
                            strcat(message, ":");
                            char port[6];
                            memset(port, 0, 6);
                            sprintf(port, "%d.", ntohs(cli_addr.sin_port));
                            strcat(message, port);
                            strcat(message, "\n");
                            printf("%s", message);
                            
                            
                            // we send the messages stored for the client
                            
                            for(auto it = listOfSubscribersSF.begin(); it != listOfSubscribersSF.end(); it++){
                                if(strcmp(it->ID_CLIENT, ID_CLIENT) == 0 ){
                                    it->connected = true;
                                    
                                    if(it->SF == 1){
                                    // we have a match
                                        // we send the messages
                                        
                                        
                                        for(int i = 0; i < (int)it->messages.size(); i++){
                                            
                                            int s = send(newSocket, it->messages[i].c_str(), it->messages[i].size(), 0);
                                            if(s < 0){
                                                printf("[SERV] Error while sending message to client\n");
                                                return -1;
                                            }
                                        }
                                        // we clear the vector of messages
                                        it->messages.clear();

                                    }
                                }
                            }

                        }
                        else{
                            // if the ID is in use, we print that the client <ID> is already connected and we close the client
                            
                            char error_message[BUFLEN];
                            memset(error_message, 0, BUFLEN);
                            strcpy(error_message, "Client ");
                            strcat(error_message, ID_CLIENT);
                            strcat(error_message, " already connected.\n");
                            printf("%s", error_message);

                            // tell the client to close
                            char exit_message[BUFLEN];
                            memset(exit_message, 0, BUFLEN);
                            strcpy(exit_message, "exit");
                            int disconnect = send(newSocket, exit_message, BUFLEN, 0);
                            if(disconnect < 0){
                                printf("[SERV] Error while disconnecting client\n");
                                return -1;
                            }
                            close(newSocket);

                        }            
                        ////////////////////////////
                }
                else{
                    
                    // we receive a message from a TCP client already connected
                    char buffer[BUFLEN];
                    memset(buffer, 0, BUFLEN);
                    int receive = recv(sock, &buffer, BUFLEN, 0);
                    
                    if(receive < 0){
                        printf("[SERV] Error while receiving message\n");
                        return -1;
                    }

                    // we check if the client wants to disconnect
                    if( strcmp(buffer, "exit") == 0 || receive == 0){
                        // the client disconnected
                        // we search for the client in the vector of clients
                        for(auto it = clientsConnected.begin(); it != clientsConnected.end(); it++){
                            if(sock == it->socket){

                                // we found the client
                                // we print that the client <ID> disconnected
                                char message[BUFLEN];
                                memset(message, 0, BUFLEN);
                                strcpy(message, "Client ");
                                strcat(message, it->ID_CLIENT);
                                strcat(message, " disconnected.\n");
                                printf("%s", message);
                                // we make his subscriptions disconnected
                                for(auto it2 = listOfSubscribersSF.begin(); it2 != listOfSubscribersSF.end(); it2++){
                                    if(strcmp(it2->ID_CLIENT, it->ID_CLIENT) == 0){
                                        it2->connected = false;
                                    }
                                }
                                
                                // we remove the client from the vector of clients
                                clientsConnected.erase(it);

                                close(sock);
                                FD_CLR(sock, &read_fds);
                                break;
                            }
                        }

                    }

                    // we check if the client wants to subscribe 
                    
                    if(strncmp(buffer,"subscribe",9) == 0){
                        
                        char topicStr[51];
                        char subs[10];
                        char SF[2];
                        int SFint;
                        sscanf(buffer,"%s %s %s", subs, topicStr, SF);
                        
                        
                        if(SF[0] == '1'){
                            SFint = 1;
                        }
                        else{
                            SFint = 0;
                        }

                        
                        for(auto it = clientsConnected.begin(); it != clientsConnected.end(); it++){
                                if(sock == it->socket){
                                    bool alreadyexists = false;

                                    for(auto it2 = listOfSubscribersSF.begin(); it2 != listOfSubscribersSF.end(); it2++){
                                        if(strcmp(it->ID_CLIENT, it2->ID_CLIENT) == 0){
                                            if(strcmp(it2->topic, topicStr) == 0){
                                                it2->connected = true;
                                                alreadyexists = true;
                                            }
                                        }
                                    }
                                    if(alreadyexists == false){
                                        struct subscriber newSubs;
                                        memset(newSubs.ID_CLIENT, 0, 11);
                                        strcpy(newSubs.ID_CLIENT, it->ID_CLIENT);
                                        strcpy(newSubs.topic, topicStr);
                                        newSubs.SF = SFint;
                                        newSubs.connected = true;
                                        listOfSubscribersSF.push_back(newSubs);
                                    } else{
                                        printf("[SERV] Error Client %s already subscribed to topic %s\n", it->ID_CLIENT, topicStr);
                                    }

                                    break;
                                }
                        }
                    }
                    // we check if the client wants to unsubscribe
                    if(strncmp(buffer,"unsubscribe",11) == 0){

                        char topicStr[51];
                        char unsubs[12];

                        sscanf(buffer,"%s %s", unsubs, topicStr);


                        for(auto it = clientsConnected.begin(); it != clientsConnected.end(); it++){
                                if(sock == it->socket){
                                    bool found = false;
                                    for(auto it2 = listOfSubscribersSF.begin(); it2 != listOfSubscribersSF.end(); it2++){
                                        if(strcmp(it->ID_CLIENT, it2->ID_CLIENT) == 0){
                                            if(strcmp(it2->topic, topicStr) == 0){
                                                
                                                // we remove the subscription
                                                listOfSubscribersSF.erase(it2);
                                                found = true;
                                                break;
                                            }
                                        }
                                    }
                                    if( found == false){
                                        printf("[SERV] Error Client %s not subscribed to topic %s\n", it->ID_CLIENT, topicStr);
                                    }
                                    break;
                                }
                        }
                    }
                }
            }
        }
    }

    // we close the sockets
    close(listenTCP);
    close(socketUDP);

}
