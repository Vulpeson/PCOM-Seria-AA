#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <string>
#include <iomanip>
#include <sstream>
#include <math.h>
#include <unordered_map>

using namespace std;


#define BUFLEN 1600
// maximul pt un mesaj care are ip:port - topic - data_type - value

int main(int argc, char *argv[]) {
    
    if(argc != 4) {
        printf("Usage: %s <ID_Client> <IP_Server> <Port_Server>\n", argv[0]);
        return 1;
    }
    
    
    
    // get port
    int port = atoi(argv[3]);
    if(port == 0) {
        printf("Invalid port\n");
        return 1;
    }
    // disable stdout buffering
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    fd_set clientFd, tmpFd;

    FD_ZERO(&clientFd);
    FD_ZERO(&tmpFd);
    FD_SET(STDIN_FILENO, &clientFd);
    // create socket
    int socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if(socketfd < 0){
        printf("[CLIENT] Unable to create socket\n");
        return -1;
    }
    // set server address
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(struct sockaddr_in));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons((uint16_t)port);
    // convert ip to binary
    int ret = inet_aton(argv[2], &serv_addr.sin_addr);
    if(ret == 0) {
        printf("Invalid IP address\n");
        return 1;
    }

    // disable neagle alg
    int neagle = 1;
    int res = setsockopt(socketfd, IPPROTO_TCP, TCP_NODELAY, &neagle, sizeof(neagle));
    if(res < 0){
        printf("[CLIENT] Error while disabling neagle algorithm\n");
        return -1;
    }
    // connect to server
    ret = connect(socketfd, (struct sockaddr*) &serv_addr, sizeof(struct sockaddr_in));
    if(ret < 0) {
        printf("[CLIENT] Unable to connect to server\n");
        return -1;
    }

    // send ID_Client to server
    ret = send(socketfd, argv[1], strlen(argv[1]), 0);
    if(ret < 0) {
        printf("[CLIENT] Unable to send ID_Client to server\n");
        return -1;
    }

    // add socket to fd set
    FD_SET(socketfd, &clientFd);
    

    int fdMax = socketfd;

    // main loop
    while(1){
        tmpFd = clientFd;
        ret = select(fdMax + 1, &tmpFd, NULL, NULL, NULL);
        if(ret < 0) {
            printf("[CLIENT] Select failed\n");
            return -1;
        }

        // check if from stdin
        if(FD_ISSET(STDIN_FILENO, &tmpFd)) {

            char buffer[BUFLEN];
            memset(buffer, 0, BUFLEN);
            fgets(buffer, BUFLEN - 1, stdin);
            
            
            if(strncmp(buffer, "exit", 4) == 0 || strlen(buffer) == 0) {
                // check if exit
                // send exit to server
                
                if(ret < 0) {
                    printf("[CLIENT] Unable to send message to server\n");
                    return -1;
                }
                return -1;
            } else
            if(strncmp(buffer, "subscribe", 9) == 0) {
                // check if subscribe
                
                ret = send(socketfd, buffer, strlen(buffer), 0);
                if(ret < 0) {
                    printf("[CLIENT] Unable to send message to server\n");
                    return -1;
                }
                printf("Subscribed to topic.\n");
            } else
            if(strncmp(buffer, "unsubscribe", 11) == 0) {
                // check if unsubscribe
                ret = send(socketfd, buffer, strlen(buffer) , 0);
                if(ret < 0) {
                    printf("[CLIENT] Unable to send message to server\n");
                    return -1;
                }
                printf("Unsubscribed from topic.\n");
            } else {
                // invalid command
                printf("[CLIENT] Invalid command\n");
            }

        }

        // check if from server
        if(FD_ISSET(socketfd, &tmpFd)) {
            // receive message from server
            char buffer[BUFLEN];
            
            memset(buffer, 0, BUFLEN);
            
            int ret = recv(socketfd, &buffer, BUFLEN, 0);
            

            if(ret < 0) {
                printf("[CLIENT] Unable to receive message from server\n");
                return -1;
            }
            
            
            // check if server closed connection
            if(strncmp(buffer, "exit", 4) == 0 || ret == 0) {
                printf("[CLIENT] Server closed connection\n");
                break;
            }
            
            
            // print buffer

            printf("%s", buffer);
            printf("\n");
            
            
        }
        
    }
    
    close(socketfd);

    return 0;

    

}
