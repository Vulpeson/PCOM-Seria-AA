
#include "include/lib.h"
#include "include/list.h"
#include "include/queue.h"
#include "include/protocols.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

struct route_table_entry *rtable;
int rtable_len;



// make a binary tree that holds elements of the routing table
struct node {
	// left is for 0 and right is for 1
	struct route_table_entry *rte;
	struct node *left;
	struct node *right;
};

// create node function for the binary tree

struct node* create_node(){

	struct node *root = malloc(sizeof(struct node));
	//printf("node created\n");
	root->rte = NULL;
	root->left = NULL;
	root->right = NULL;
	
	return root;
}

// insert a node in the binary tree

void insert_node(struct node *root, struct route_table_entry *rte){
	// create a bit mask that will be used to check if the bit is 0 or 1 
	// i started with the most significant bit
	// then i will change the actualbit for each octet
	// run through the bits of the actualbit from left to right
	uint32_t actualbit = ntohl(0b10000000000000000000000000000000); // 0000 0000 0000 0000 0000 0000 0000 0000
	
	uint32_t actualbit2 = ntohl(0b00000000100000000000000000000000); // 0000 0000 1000 0000 0000 0000 0000 0000

	uint32_t actualbit3 = ntohl(0b00000000000000001000000000000000); // 0000 0000 0000 0000 1000 0000 0000 0000

	uint32_t actualbit4 = ntohl(0b00000000000000000000000010000000); // 0000 0000 0000 0000 0000 0000 1000 0000

	struct node *actualnode = malloc(sizeof(struct node));
	actualnode = root;
	// example of print that shows the node tried and the current state of the actualbit
	//printf("node tried %d.%d.%d.%d - ", (uint8_t)(rte->prefix), (uint8_t)(rte->prefix >> 8), (uint8_t)(rte->prefix >> 16), (uint8_t)(rte->prefix >> 24));
	//printf("- current state: %d.%d.%d.%d - \n", (uint8_t)(actualbit), (uint8_t)(actualbit >> 8), (uint8_t)(actualbit >> 16), (uint8_t)(actualbit >> 24));
	int iter = 1;
	// while for the mask of the actual rte 
	while((rte->mask & actualbit) != 0){
		//printf("iter %d - ", iter);
		// left is for 0 and right is for 1
		if((rte->prefix & (actualbit)) == 0){
			//printf("0 - current state: %d.%d.%d.%d -\n", (uint8_t)(actualbit), (uint8_t)(actualbit >> 8), (uint8_t)(actualbit >> 16), (uint8_t)(actualbit >> 24));
			if(actualnode->left == NULL){
				// if the left node is null create a new node
				actualnode->left = create_node();
			}
			// go to the left node
			actualnode = actualnode->left;

		}
		else{
			//printf("1 - current state: %d.%d.%d.%d - \n", (uint8_t)(actualbit), (uint8_t)(actualbit >> 8), (uint8_t)(actualbit >> 16), (uint8_t)(actualbit >> 24));
			if(actualnode->right == NULL){
				// if the right node is null create a new node
				actualnode->right = create_node();
			}
			// go to the right node
			actualnode = actualnode->right;
		}
		// shift the actualbit to the right
		actualbit = actualbit >> 1;
		// change the actualbit for each octet
		if(iter == 8){
			actualbit = actualbit2;
		
		}
		else if(iter == 16){
			actualbit = actualbit3;
		
		}
		else if(iter == 24){
			actualbit = actualbit4;
		
		}
		else if(iter == 32){
			break;
		}
		// increment the iterator
		iter++;
	}

	//printf(" - node added \n" );
	// add the rte to the actual node
	actualnode->rte = rte;
	

}

// insert the routing table in the binary tree
void insert_tree(struct node *root){
	printf("tree  \n");
	for (int i = 0; i < rtable_len; i++){
		insert_node(root, &rtable[i]);
	}
	printf("%d nodes inserted\n", rtable_len);
}

// find the best route for a given ip
struct route_table_entry *get_best_route(struct node *root, uint32_t ip_dest) {
	// create a bit mask that will be used to check if the bit is 0 or 1
	// i started with the most significant bit
	// then i will change the actualbit for each octet

	uint32_t actualbit = ntohl(0b10000000000000000000000000000000); // 0000 0000 0000 0000 0000 0000 0000 0000
	// run through the bits of the actualbit from left to right
	uint32_t actualbit2 = ntohl(0b00000000100000000000000000000000); // 0000 0000 1000 0000 0000 0000 0000 0000

	uint32_t actualbit3 = ntohl(0b00000000000000001000000000000000); // 0000 0000 0000 0000 1000 0000 0000 0000

	uint32_t actualbit4 = ntohl(0b00000000000000000000000010000000); // 0000 0000 0000 0000 0000 0000 1000 0000

	// create a pointer to the best route
	// the best route is the one with the longest prefix match
	
	struct route_table_entry *best_route = NULL;
	printf("node tried %d.%d.%d.%d - ", (uint8_t)(ip_dest), (uint8_t)(ip_dest >> 8), (uint8_t)(ip_dest >> 16), (uint8_t)(ip_dest >> 24));
	
	struct node *actualnode = malloc(sizeof(struct node));
	actualnode = root;
	int iter = 1;
	while(1){
	
		if((ip_dest & actualbit) == 0){
			if(actualnode->left == NULL){
				if(best_route != NULL){

					printf("best route found\n");
				}
				else{
					// if the left node is null and there is no best route found
					printf("no route found\n");
				}
				//printf("best route prefix: %d.%d.%d.%d \n ", (uint8_t)(best_route->prefix), (uint8_t)(best_route->prefix >> 8), (uint8_t)(best_route->prefix >> 16), (uint8_t)(best_route->prefix >> 24));
				//printf("best route mask: %d.%d.%d.%d \n ", (uint8_t)(best_route->mask), (uint8_t)(best_route->mask >> 8), (uint8_t)(best_route->mask >> 16), (uint8_t)(best_route->mask >> 24));
				//printf("best route nexthop: %d.%d.%d.%d \n ", (uint8_t)(best_route->next_hop), (uint8_t)(best_route->next_hop >> 8), (uint8_t)(best_route->next_hop >> 16), (uint8_t)(best_route->next_hop >> 24));
				//printf("best route interface: %d \n ", (int)(best_route->interface));
				return best_route;
			}
			actualnode = actualnode->left;
		}
		else{
			if(actualnode->right == NULL){
				if(best_route != NULL){
					
					printf("best route found\n");
				}
				else{
					// if the right node is null and there is no best route found
					printf("no route found\n");
				}
				
				//printf("best route prefix: %d.%d.%d.%d \n ", (uint8_t)(best_route->prefix), (uint8_t)(best_route->prefix >> 8), (uint8_t)(best_route->prefix >> 16), (uint8_t)(best_route->prefix >> 24));
				//printf("best route mask: %d.%d.%d.%d \n ", (uint8_t)(best_route->mask), (uint8_t)(best_route->mask >> 8), (uint8_t)(best_route->mask >> 16), (uint8_t)(best_route->mask >> 24));
				//printf("best route nexthop: %d.%d.%d.%d \n ", (uint8_t)(best_route->next_hop), (uint8_t)(best_route->next_hop >> 8), (uint8_t)(best_route->next_hop >> 16), (uint8_t)(best_route->next_hop >> 24));
				//printf("best route interface: %d \n ", (int)(best_route->interface));
				return best_route;
			}
			actualnode = actualnode->right;
		}

		if(actualnode->rte != NULL){
			// if the actual node has a route table entry then it is the best route found so far 
				best_route = actualnode->rte;
		}
		// shift the actualbit to the right
		actualbit = actualbit >> 1;
		// if the octet is changed then the actualbit must be changed too
		if(iter == 8){
			actualbit = actualbit2;
		
		}
		else if(iter == 16){
			actualbit = actualbit3;
		
		}
		else if(iter == 24){
			actualbit = actualbit4;
		
		}
		else if(iter == 32){
			break;
		}
		iter++;
		
	}

	return NULL;

}

// liniar search for the best route 
// this function is not used anymore
// it is replaced by the function get_best_route which uses the trie structure
/*


struct route_table_entry *get_best_route(uint32_t ip_dest) {
	
	struct route_table_entry *best_route = NULL;
	
	
	for (int i = 0; i < rtable_len; i++)
	{
		if ((rtable[i].prefix & rtable[i].mask) == (ip_dest & rtable[i].mask) )
		{	
			if(best_route == NULL || rtable[i].mask > best_route->mask){
				
				best_route = &rtable[i];
			}
				
		}
	}

	
	return best_route;
}
*/

/* Mac table */
struct arp_entry *mac_table = NULL;
int mac_table_len = 0;
// the mac table is a list of arp entries
// function that finds the mac address of a given ip address
// if the mac address is not found then it returns null
// if the mac address is found then it returns the arp entry
// this function is similar to the ones used in the previous labs (lab4)
struct arp_entry *get_mac_entry(uint32_t ip_dest) {
	
	for (int i = 0; i < mac_table_len; i++)
	{
		if (mac_table[i].ip == ip_dest)
		{
			return &mac_table[i];
		}
	}
	
	
	return NULL;
}


int main(int argc, char *argv[])
{
	char buf[MAX_PACKET_LEN];

	// Do not modify this line
	init(argc - 2, argv + 2);
	rtable = malloc(sizeof(struct route_table_entry) * 100000);
	/* DIE is a macro for sanity checks */
	DIE(rtable == NULL, "memory");

	mac_table = malloc(sizeof(struct  arp_entry) * 100);
	DIE(mac_table == NULL, "memory");

	// read the route table
	rtable_len = read_rtable(argv[1], rtable);
	printf("passed rtable\n");
	// be sure there are no anomalies in the route table
	// like a prefix that is not masked
	for(int i = 0 ; i < rtable_len; i++){
		rtable[i].prefix = rtable[i].prefix & rtable[i].mask;
	}

	mac_table_len = parse_arp_table("arp_table.txt",mac_table);
	
	struct node *root = create_node();
	insert_tree(root);
	printf("made tree \n");
	// populam tabelele de rutare si mac


	while (1) {

			int interface;
			size_t len;
			interface = recv_from_any_link(buf, &len);

			DIE(interface < 0, "get_message");
			printf("We have received a packet\n");

			struct ether_header *eth_hdr = (struct ether_header *) buf;
			
			// check if the packet is for this router
			bool is_for_me = true;
			bool is_broadcast = true;

			// allocations 
			uint8_t *mac_adr = malloc(6 * sizeof(uint8_t));
			uint8_t *mymac = malloc(sizeof(uint8_t)*6);
			uint32_t *ip_interfata = malloc(sizeof(uint32_t));
			
			get_interface_mac(interface, mac_adr); 
			// check if the packet is for this router
		
			for (int i = 0; i < 6; i++)
			{
				if (eth_hdr->ether_dhost[i] != mac_adr[i])
				{
					is_for_me = false;
					break;
				}

				if (eth_hdr->ether_dhost[i] != 0xFF)
				{
					is_broadcast = false;
					break;
				}
			}
			

			
			// this if statement is used to determine the nature of the packet
			if ((is_for_me == false && is_broadcast == false ))
			{	// if the packet is not for this router then we continue
				printf("Packet is not for me\n");
				continue;
			}
			else
			if(eth_hdr->ether_type == htons(0x0800)){
				// if the packet is an IP packet then we continue
				printf("IP packet received\n");
				
				struct iphdr *ip_hdr = (struct iphdr *)(buf + sizeof(struct ether_header));
				// check if the packet is for this router
				// this function inet_pton is taken from the forum 
				// it converts the ip address from string to binary
				// and then we compare it with the ip address of the interface
				// if they are the same then the packet is for this router
				// if not then the packet is not for this router
				// and we continue
			
				
				int s = inet_pton(AF_INET, get_interface_ip(interface), ip_interfata);
				if(s <= 0){
					printf("inet_pton failed\n");
				}

				if(ip_hdr->protocol == 1 && *ip_interfata == ip_hdr->daddr){
					// if the packet is an ICMP packet and it is for this router
					// we create an ICMP echo reply packet
					// and we send it back to the sender
					
					printf("ICMP packet received\n");
					struct icmphdr *icmp_hdr = (struct icmphdr *)(buf + sizeof(struct ether_header) + sizeof(struct iphdr));
					
					if(icmp_hdr->type == 8){
						printf("ICMP echo request received\n");
						char *icmp_packet = malloc(sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));

						struct ether_header *icmp_eth_hdr = (struct ether_header *) icmp_packet;
						struct iphdr *icmp_ip_hdr = (struct iphdr *)(icmp_packet + sizeof(struct ether_header));
						struct icmphdr *icmp_hdr = (struct icmphdr *)(icmp_packet + sizeof(struct ether_header) + sizeof(struct iphdr));
						// we create the ICMP echo reply packet according to the specifications found in the RFC
						icmp_eth_hdr->ether_type = htons(0x0800);
						memcpy(icmp_eth_hdr->ether_dhost, eth_hdr->ether_shost, 6);
						memcpy(icmp_eth_hdr->ether_shost, eth_hdr->ether_dhost, 6);
						
						icmp_ip_hdr->version = 4;
						icmp_ip_hdr->ihl = 5;
						icmp_ip_hdr->tos = 0;
						icmp_ip_hdr->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
						icmp_ip_hdr->id = 0;
						icmp_ip_hdr->frag_off = 0;
						icmp_ip_hdr->ttl = 100;
						icmp_ip_hdr->protocol = 1;
						icmp_ip_hdr->check = 0;
						icmp_ip_hdr->saddr = ip_hdr->daddr;
						icmp_ip_hdr->daddr = ip_hdr->saddr;
						icmp_ip_hdr->check = htons(checksum((uint16_t*)icmp_ip_hdr, sizeof(struct iphdr)));

						icmp_hdr->type = 0;
						icmp_hdr->code = 0;
						icmp_hdr->checksum = 0;
						icmp_hdr->checksum = checksum((uint16_t*)icmp_hdr, sizeof(struct icmphdr));

						// we send the packet back to the sender
						send_to_link(interface, icmp_packet, sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));
						continue;
					}
					
				}

				if(checksum((uint16_t*)ip_hdr,sizeof(struct iphdr)) != 0) {
					// check if the checksum is correct
					
					printf("IP checksum failed\n");
					printf("packet dropped\n");
					continue;
				}
				// check if time exceeded
				if((ip_hdr->ttl <= 1)){
					// check if ttl is greater than 1
					printf("time exceeded\n");

					// send icmp time exceeded
					char *icmp_packet = malloc(sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));
					// we create the ICMP time exceeded packet according to the specifications found in the RFC
					// this is similar to the ICMP echo reply packet
					struct ether_header *icmp_eth_hdr = (struct ether_header *) icmp_packet;
					struct iphdr *icmp_ip_hdr = (struct iphdr *)(icmp_packet + sizeof(struct ether_header));
					struct icmphdr *icmp_hdr = (struct icmphdr *)(icmp_packet + sizeof(struct ether_header) + sizeof(struct iphdr));

					icmp_eth_hdr->ether_type = htons(0x0800);
					memcpy(icmp_eth_hdr->ether_dhost, eth_hdr->ether_shost, 6);
					memcpy(icmp_eth_hdr->ether_shost, eth_hdr->ether_dhost, 6);


					icmp_ip_hdr->tos = 0;
					icmp_ip_hdr->frag_off = 0;
					icmp_ip_hdr->version = 4;
					icmp_ip_hdr->ihl = 5;
					icmp_ip_hdr->id = 1;
					icmp_ip_hdr->ttl = 100;
					icmp_ip_hdr->protocol = 1;
					icmp_ip_hdr->saddr = ip_hdr->daddr;
					icmp_ip_hdr->daddr = ip_hdr->saddr;
					icmp_ip_hdr->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
					icmp_ip_hdr->check = htons(checksum((uint16_t*)icmp_ip_hdr, sizeof(struct iphdr)));

					icmp_hdr->type = 11;
					icmp_hdr->code = 0;
					icmp_hdr->checksum = htons(checksum((uint16_t*)icmp_hdr, sizeof(struct icmphdr)));
					icmp_hdr->un.echo.id = 0;
					icmp_hdr->un.echo.sequence = 0;



					send_to_link(interface, icmp_packet, sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));
					continue;
				}

				struct route_table_entry *bestrt = get_best_route(root,ip_hdr->daddr);

				/*
				struct route_table_entry *bestrt = get_best_route(ip_hdr->daddr);
				// used if we want to use the linier search
				*/
				// check if the destination is reachable
				if(bestrt == NULL){
					
					// send icmp destination unreachable
					printf("Destination unreachable\n");

					// send icmp time exceeded
					char *icmp_packet = malloc(sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));
					// we create the ICMP time exceeded packet according to the specifications found in the RFC
					// this is similar to the ICMP echo reply packet and the ICMP time exceeded packet

					struct ether_header *icmp_eth_hdr = (struct ether_header *) icmp_packet;
					struct iphdr *icmp_ip_hdr = (struct iphdr *)(icmp_packet + sizeof(struct ether_header));
					struct icmphdr *icmp_hdr = (struct icmphdr *)(icmp_packet + sizeof(struct ether_header) + sizeof(struct iphdr));

					icmp_eth_hdr->ether_type = htons(0x0800);
					memcpy(icmp_eth_hdr->ether_dhost, eth_hdr->ether_shost, 6);
					memcpy(icmp_eth_hdr->ether_shost, eth_hdr->ether_dhost, 6);


					icmp_ip_hdr->tos = 0;
					icmp_ip_hdr->frag_off = 0;
					icmp_ip_hdr->version = 4;
					icmp_ip_hdr->ihl = 5;
					icmp_ip_hdr->id = 1;
					icmp_ip_hdr->ttl = 100;
					icmp_ip_hdr->protocol = 1;
					icmp_ip_hdr->saddr = ip_hdr->daddr;
					icmp_ip_hdr->daddr = ip_hdr->saddr;
					icmp_ip_hdr->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr));
					icmp_ip_hdr->check = htons(checksum((uint16_t*)icmp_ip_hdr, sizeof(struct iphdr)));

					icmp_hdr->type = 3;
					icmp_hdr->code = 0;
					icmp_hdr->checksum = htons(checksum((uint16_t*)icmp_hdr, sizeof(struct icmphdr)));
					icmp_hdr->un.echo.id = 0;
					icmp_hdr->un.echo.sequence = 0;



					send_to_link(interface, icmp_packet, sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr));
					continue;

				}
		
				
				
				// decrement ttl
				// redo checksum
				ip_hdr->ttl = ip_hdr->ttl - 1;
				//ip_hdr->check = ~(~(ip_hdr->check) + ~((uint16_t)(ip_hdr->ttl + 1)) + (uint16_t)ip_hdr->ttl) - 1;
				ip_hdr->check = 0;
				ip_hdr->check = htons(checksum((uint16_t*)ip_hdr,sizeof(struct iphdr)));
				
				struct arp_entry *mac_entry = get_mac_entry(bestrt->next_hop);
				// check if the mac address is known
				// if not send arp request
				// if yes send packet
			
				if(mac_entry == NULL){
						printf("Error: mac_entry not found \n");
						printf("Sending arp request\n");
						
						continue;
				}	

				// change source mac address
				
				get_interface_mac(bestrt->interface, mymac);
				memcpy(eth_hdr->ether_shost, mymac, 6);
				
				memcpy(eth_hdr->ether_dhost, &mac_entry->mac, 6);	
		
				printf("mac changed!\n");

				// send packet
				send_to_link(bestrt->interface, buf, len);
				printf("packet sent!\n");
			


			}
			else
			if(eth_hdr->ether_type == htons(0x0806)){
					// ARP packet
					printf("ARP packet received\n");

					struct arp_header *arp_hdr = (struct arp_header *)(buf + sizeof(struct ether_header));
		
					if(arp_hdr->op == htons(0x0002)){
						// ARP reply
						printf("ARP reply received\n");
					}
					else
					if(arp_hdr->op == htons(0x0001)){
						// ARP request
						printf("ARP request received\n");
							
					}
					
			}
			else{
				// not IP or ARP packet
				printf("Not IP or ARP packet\n");
				continue;
			}
		}
}	