#include "list.h"
#include <stdlib.h>

list cons(void *buf,int len, void* bestrt, list next)
{
	list temp = malloc(sizeof(struct cell));
	temp->buf = buf;
	temp->len = len;
	temp->bestrt = bestrt;
	temp->next = next;
	return temp;
}

list cdr_and_free(list l)
{
	list temp = l->next; 
	free(l);
	return temp;
}
