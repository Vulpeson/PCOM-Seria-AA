#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "parson/parson.h"

#define HOST "34.254.242.81"
#define PORT 8080


int main(int argc, char *argv[])
{

    int sockfd;
    int library_access = 0;
    int logged_in = 0;
    char token[1000];
    char cookie[1000];
    // prints the welcome message and the commands 
    printf("Welcome to the library!\n");
    printf("Commands:\n");
    printf("register - login - enter_library - get_books - get_book - add_book - delete_book - logout - exit\n\n");

    while(1){
        // starts reading commands
        char command[1000];
        fgets(command, 1000, stdin);
        
        if(strncmp(command,"exit",4) == 0){
            // close the connection to the server
            return 0;
        }
        else if(strncmp(command,"register",8) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);
            // read username and password
            char username[1000];
            printf("username: ");
            fgets(username, 1000, stdin);
            username[strcspn(username, "\n")] = 0;
            // check if username is empty or it has spaces
            if(strlen(username) == 0 || strchr(username, ' ') != NULL){
                printf("Invalid username.\n\n");
                close(sockfd);
                continue;
            }
            char password[1000];
            printf("password: ");
            fgets(password, 1000, stdin);
            password[strcspn(password, "\n")] = 0;
            if(strlen(password) == 0 || strchr(password, ' ') != NULL){
                printf("Invalid password.\n\n");
                close(sockfd);
                continue;
            }

            // create JSON object containing username and password
            JSON_Value *value = json_value_init_object();
            JSON_Object *object = json_value_get_object(value);
            json_object_set_string(object, "username", username);
            json_object_set_string(object, "password", password);
            char *payload = json_serialize_to_string_pretty(value);
            int size = strlen(payload);

            // create the POST request  

            char *message = compute_post_request(HOST, "/api/v1/tema/auth/register", "application/json", payload, size, NULL, NULL);

            // send the POST request
            send_to_server(sockfd, message);
            // receive the response from the server

            char *response = receive_from_server(sockfd);
            

            // check for errors and print the status 

            if(logged_in == 1){
                printf("You are already logged in.\n\n");
            }
            if (strstr(response, "error")) {
                printf("Username already in use.\n\n");
            } 
            else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            } 
            else {
                printf("Successful registration.\n\n");
            }
            
            // free the memory
            json_free_serialized_string(payload);
            json_value_free(value);
            free(message);
            free(response);
            close(sockfd);
        }
        else if(strncmp(command,"login",5) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);
            if(logged_in == 1){
                printf("You are already logged in.\n\n");
                close(sockfd);
                continue;
            }
            // read username and password
            char username[1000];
            printf("username: ");
            fgets(username, 1000, stdin);
            username[strcspn(username, "\n")] = 0;
            // check if username is empty or it has spaces
            if(strlen(username) == 0 || strchr(username, ' ') != NULL){
                printf("Invalid username.\n\n");
                close(sockfd);
                continue;
            }
            char password[1000];
            printf("password: ");
            fgets(password, 1000, stdin);
            password[strcspn(password, "\n")] = 0;
            // check if password is empty or it has spaces
            if(strlen(password) == 0 || strchr(password, ' ') != NULL){
                printf("Invalid password.\n\n");
                close(sockfd);
                continue;
            }

            // create JSON object containing username and password
            JSON_Value *value = json_value_init_object();
            JSON_Object *object = json_value_get_object(value);
            json_object_set_string(object, "username", username);
            json_object_set_string(object, "password", password);
            char *payload = json_serialize_to_string_pretty(value);
            int size = strlen(payload);

            // create the POST request
            char *message = compute_post_request(HOST, "/api/v1/tema/auth/login", "application/json", payload, size, NULL, NULL);
            /* printf("%s\n\n", message); */
            // send the POST request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status
            

            if(strstr(response,"error")){
                printf("Wrong username or password.\n\n");
            }
            else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                printf("Successful login.\n\n");
                logged_in = 1;
                
                // get the cookie from the response
                char *cookie_start = strstr(response, "connect");
                if(cookie_start == NULL){
                    printf("Error getting login cookie.\n\n");
                    close(sockfd);
                    free(message);
                    free(response);
                    json_free_serialized_string(payload);
                    json_value_free(value);
                    continue;
                }
                char *cookie_end = strstr(cookie_start, "Date");

                // we copy the cookie in a variable
                
                memset(cookie, 0, 1000);
                strncpy(cookie, cookie_start, cookie_end - cookie_start - 2);
                cookie[cookie_end - cookie_start] = '\0';
                
            }
            
            // free the memory
            json_free_serialized_string(payload);
            json_value_free(value);
            free(message);
            free(response);
            close(sockfd);
            
        }
        else if(strncmp(command,"enter_library",13) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

            // check if the user is logged in

            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                close(sockfd);
                continue;
            }
            
            // create the GET request
            char *message = compute_get_request(HOST, "/api/v1/tema/library/access", NULL, cookie, NULL);
            
            // send the GET request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status

            if(strstr(response,"error")){
                printf("Error in accessing the library.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                printf("Access granted.\n\n");
                library_access = 1;
                // get the token from the response
                char *token_start = strstr(response, "token");
                if(token_start == NULL){
                    printf("Error getting token.\n\n");
                    close(sockfd);
                    free(message);
                    free(response);
                    continue;
                }
                char *token_end = strstr(token_start, "}");

                // we copy the token in a variable
                memset(token, 0, 1000);
                strncpy(token, token_start + 8, token_end - token_start - 9);
                token[token_end - token_start - 9] = '\0';
                //printf("%s\n\n", token);
            }

            
            // free the memory
            
            free(message);
            free(response);
            close(sockfd);

        }
        else if(strncmp(command,"get_books",9) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);
            // check if the user is logged in
            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                close(sockfd);
                continue;
            }
            if(library_access == 0){
                printf("You don't have access to the library.\n\n");
                close(sockfd);
                continue;
            }
            // create the GET request
            char *message = compute_get_request(HOST, "/api/v1/tema/library/books", NULL, NULL, token);
            
            // send the GET request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the books

            if(strstr(response,"error")){
                printf("Error in getting the books.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                // get the books from the response
                char *books_start = strstr(response, "[");
                
                printf("Books:\n%s\n\n", books_start);
                
            }

            
            // free the memory
            free(message);
            free(response);
            close(sockfd);
        }
        else if(strncmp(command,"get_book",8) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

            // check if the user is logged in
            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                close(sockfd);
                continue;
            }
            // check if the user has access to the library
            if(library_access == 0){
                printf("You don't have access to the library.\n\n");
                close(sockfd);
                continue;
            }
            // read the id of the book
            char id[1000];
            printf("id: ");
            fgets(id, 1000, stdin);
            id[strcspn(id, "\n")] = 0;
            // check if the id is a number
            
            if(strspn(id, "0123456789") != strlen(id)){
                printf("Invalid id.\n\n");
                continue;
            }
            // create the GET request

            // we need to concatenate the id to the url
            char url[1000] = "/api/v1/tema/library/books/";
            strcat(url, id);
            char *message = compute_get_request(HOST, url, NULL, NULL, token);

            
            // send the GET request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status
            //printf("response: %s\n\n", response);

            if(strstr(response,"error")){
                printf("Error in getting the book.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                // get the books from the response
                char *books_start = strstr(response, "{");
            
                printf("Book:\n%s\n\n", books_start);
                
            }
            // free the memory
            free(message);
            free(response);
            close(sockfd);


        }
        else if(strncmp(command,"add_book",8) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

            // check if the user is logged in
            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                continue;
            }
            // check if the user has access to the library
            if(library_access == 0){
                printf("You don't have access to the library.\n\n");
                continue;
            }

            // read the title, author, genre and publisher of the book
            // we need to check if the strings are empty 
            char title[1000];
            printf("title: ");
            fgets(title, 1000, stdin);
            title[strcspn(title, "\n")] = 0;
            if(strlen(title) == 0){
                printf("Invalid title.\n\n");
                continue;
            }
            char author[1000];
            printf("author: ");
            fgets(author, 1000, stdin);
            author[strcspn(author, "\n")] = 0;

            if(strlen(author) == 0){
                printf("Invalid author.\n\n");
                continue;
            }
            char genre[1000];
            printf("genre: ");
            fgets(genre, 1000, stdin);
            genre[strcspn(genre, "\n")] = 0;

            if(strlen(genre) == 0){
                printf("Invalid genre.\n\n");
                continue;
            }
            char publisher[1000];
            printf("publisher: ");
            fgets(publisher, 1000, stdin);
            publisher[strcspn(publisher, "\n")] = 0;

            if(strlen(publisher) == 0){
                printf("Invalid publisher.\n\n");
                continue;
            }
            
            char page_count_string[1000];
            printf("page_count: ");
            fgets(page_count_string, 1000, stdin);
            page_count_string[strcspn(page_count_string, "\n")] = 0;
            // check if the page_count_string is a number or is empty
            if(strlen(page_count_string) == 0){
                printf("Invalid page_count.\n\n");
                continue;
            }
            if(strspn(page_count_string, "0123456789") != strlen(page_count_string)){
                printf("Invalid page_count.\n\n");
                continue;
            }

            // create JSON object containing the book
            JSON_Value *value = json_value_init_object();
            JSON_Object *object = json_value_get_object(value);
            json_object_set_string(object, "title", title);
            json_object_set_string(object, "author", author);
            json_object_set_string(object, "genre", genre);
            json_object_set_string(object, "publisher", publisher);
            json_object_set_number(object, "page_count", atoi(page_count_string));
            char *payload = json_serialize_to_string_pretty(value);
            int size = strlen(payload);
            // create the POST request
            char *message = compute_post_request(HOST, "/api/v1/tema/library/books", "application/json", payload, size, NULL, token);

            // send the POST request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status
            

            if(strstr(response,"error")){
                printf("Error in adding the book.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                printf("Book added.\n\n");
            }

            // free the memory
            json_free_serialized_string(payload);
            json_value_free(value);
            free(message);
            free(response);
            close(sockfd);

        }
        else if(strncmp(command,"delete_book",11) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

            // check if the user is logged in
            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                continue;
            }
            // check if the user has access to the library
            if(library_access == 0){
                printf("You don't have access to the library.\n\n");
                continue;
            }
            // read the id of the book
            char id[1000];
            printf("id: ");
            fgets(id, 1000, stdin);
            id[strcspn(id, "\n")] = 0;
            
            if(strspn(id, "0123456789") != strlen(id)){
                printf("Invalid id.\n\n");
                continue;
            }
            // create the DELETE request

            // we need to concatenate the id to the url
            char url[1000] = "/api/v1/tema/library/books/";
            strcat(url, id);
            char *message = compute_delete_request(HOST, url, NULL, NULL, token);

            
            // send the DELETE request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status
            

            if(strstr(response,"error")){
                printf("Error in deleting the book.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                printf("Book deleted.\n\n");
            }
            // free the memory
            free(message);
            free(response);
            close(sockfd);

        }
        else if(strncmp(command,"logout",6) == 0){
             // open connection to server
            sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

            // check if the user is logged in
            if(logged_in == 0){
                printf("You are not logged in.\n\n");
                continue;
            }
            // create the GET request
            char *message = compute_get_request(HOST, "/api/v1/tema/auth/logout", NULL, cookie, NULL);
            // send the GET request
            send_to_server(sockfd, message);
            // receive the response from the server
            char *response = receive_from_server(sockfd);
            // check for errors and print the status
            

            if(strstr(response,"error")){
                printf("Error in logging out.\n\n");
            } else if(strstr(response, "Too many requests")){
                printf("Too many requests.\n\n");
            }
            else{
                printf("Successful logout.\n\n");
                logged_in = 0;
                library_access = 0;
            }
        }
        else{
            printf("Invalid command!\n");
        }
        
        

    }
    

    return 0;
}
