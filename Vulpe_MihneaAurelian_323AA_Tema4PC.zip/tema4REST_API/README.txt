
## Vulpe Mihnea-Aurelian - 323AA - Tema 4 - 17.05.2023
-------------------------------------------------------------------------------
#### Summary:
    I solved all the tasks and all commands are working properly.
    I do have used the HTTP laboratory as a base for this project and i have used the same structure for the code.
    In the request.h i have functions for POST GET and DELETE.
    I do use parson for JSON messages
    

-------------------------------------------------------------------------------
#### TASKS:
    - register - it uses the POST method to register a new user and it checks if the user is already registered
        - we check if the data is valid by checking if it is empty or not or if have a space in the username or password
        - we check if the username is already registered
    - login - it uses the POST method to login a user and it checks if the user is already logged in
        - we check if the data is valid by checking if it is empty or not or if have a space in the username or password
    - enter_library - it uses the GET method to get the token and it checks if the user is logged in
    - get_books - it uses the GET method to get the books and it checks if the user is logged in and if the token is valid
    - get_book - it uses the GET method to get a book and it checks if the user is logged in and if the token is valid
    - add_book - it uses the POST method to add a book and it checks if the user is logged in and if the token is valid
        - we check if the data is valid by checking if it is empty or not + check if the page_count is a number
    - delete_book - it uses the DELETE method to delete a book and it checks if the user is logged in and if the token is valid
    - logout - it uses the GET method to logout a user and it checks if the user is logged in 
    - exit - closes the program
    
-------------------------------------------------------------------------------



    


